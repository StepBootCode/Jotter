/*
 *
 *  Created by Sergey Stepchenkov on 02.10.20 17:10
 *  Copyright (c) 2020. All rights reserved.
 *  More info on www.bootcode.ru
 *  Last modified 02.10.20 17:10
 *
 */

package ru.bootcode.jotter;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;
import java.util.Date;

import phelat.widget.PlusTextView;
import ru.bootcode.jotter.database.Note;

public class EditNoteActivity extends AppCompatActivity {

    int img_id = 0;
    boolean check = false;
    boolean crypto = false;
    Date dateTo = new Date();
    TextView tvName;
    EditText teNote;
    TextView tvDate;
    Button btDate;
    Calendar dateAndTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        tvName = findViewById(R.id.tvName);

        PlusTextView teNotePlusTextView = (PlusTextView) findViewById(R.id.teNotePlusTextView);
        teNotePlusTextView.setFont("Font name in assets folder");

        tvDate = findViewById(R.id.tvDate);
        dateAndTime=Calendar.getInstance();

        btDate = findViewById(R.id.btDate);

        setInitialDateTime();


        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*
                Note note = new Note();

                note.name = (String) tvName.getText();              //Наименование записи
                note.date = new Date();                             //Датаи время записи
                note.note= String.valueOf(teNote.getText());        //сама запись
                note.img_id = img_id;                               // Ссылка на картинку или null
                note.check = check;                                 //Истина если есть срок
                note.crypto = crypto;                               // Истина если шифруется/требуется пароль
                note.todate= dateTo;             //срок исполнения
                */
                //JotterDatabase.Builder

                Snackbar.make(view, "Add new note", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    // установка начальных даты и времени
    private void setInitialDateTime() {
        tvDate.setText(DateUtils.formatDateTime(EditNoteActivity.this,
                dateAndTime.getTimeInMillis(),
                DateUtils.FORMAT_SHOW_DATE | DateUtils.FORMAT_SHOW_YEAR
                        | DateUtils.FORMAT_SHOW_TIME));
    }

    // отображаем диалоговое окно для выбора даты
    public void setDate(View v) {
        new DatePickerDialog(this, d,
                dateAndTime.get(Calendar.YEAR),
                dateAndTime.get(Calendar.MONTH),
                dateAndTime.get(Calendar.DAY_OF_MONTH))
                .show();
    }

    // установка обработчика выбора даты
    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            dateAndTime.set(Calendar.YEAR, year);
            dateAndTime.set(Calendar.MONTH, monthOfYear);
            dateAndTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            setInitialDateTime();
        }
    };

}
